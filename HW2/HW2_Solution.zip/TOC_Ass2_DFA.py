class Mod3DFA:
    current_state = None;
    def __init__(self, transition_function, start_state, accept_states):
        self.transition_function = transition_function;
        self.start_state = start_state;
        self.accept_states = accept_states;
        self.current_state = start_state;
        return;
    
    def transition(self, input):
        if ((self.current_state, input) not in self.transition_function.keys()):
            self.current_state = 'q3';
            return;
        self.current_state = self.transition_function[(self.current_state, input)];
        return;
    
    def check_if_in_accept_state(self):
        return self.current_state in accept_states;
    
    def go_to_initial_state(self):
        self.current_state = self.start_state;
        return;
    
    def processString(self, input_list):
        self.go_to_initial_state();
        for i in input_list:
            self.transition(i);
        return self.check_if_in_accept_state();

t= dict();
t[('q0', '0')] = 'q0';
t[('q0', '1')] = 'q1';
t[('q1', '0')] = 'q2';
t[('q1', '1')] = 'q0';
t[('q2', '0')] = 'q1';
t[('q2', '1')] = 'q2';
start_state = 'q0';
accept_states = {'q0'};
d= Mod3DFA( t, start_state, accept_states);
inp_program = '011';
print (d.processString(inp_program));
